import time
from threading import Thread

import pandas as pd

from ibapi.client import EClient
from ibapi.contract import Contract
from ibapi.wrapper import EWrapper


class Trading_App(EWrapper, EClient):
    def __init__(self):
        EClient.__init__(self, self)
        self.positions = {}  # Dictionnaire pour stocker les positions ouvertes

    def position(self, account, contract: Contract, pos, avgCost):
        # Callback qui reçoit les informations de position
        if pos > 0:
            position_type = "ACHAT"  # Position longue
        elif pos < 0:
            position_type = "VENTE"  # Position courte
        else:
            position_type = "NEUTRE"

        self.positions[contract.symbol] = {
            "Type": position_type,
            "Quantité": abs(pos),
            "Coût Moyen": avgCost,
            "Devise": contract.currency,
            "Instrument": contract.secType
        }

    def positionEnd(self):
        # Callback indiquant la fin de la transmission des positions
        print("Positions:", self.positions)
        self.disconnect()  # Déconnexion après avoir reçu toutes les positions

    def retPostions(self):
        return self.positions


def main():
    app = Trading_App()
    app.connect("127.0.0.1", 7497, clientId=1)

    con_thread = Thread(target=lambda: app.run())
    con_thread.start()

    time.sleep(1)  # Laisser le temps pour la connexion

    app.reqPositions()  # Demander les positions ouvertes
    pos = app.retPostions()
    time.sleep(3)  # Attendre la réception des données de position

    con_thread.join()  # Attendre que le thread se termine proprement

    data = pd.DataFrame(pos)
    data = data.loc[:, data.loc["Quantité"] != 0]

    print(data['GILD']['Quantité'])

    def position(action, type):
        present = "ok"
        print(data[action][type])
        print(data[action].name)
        return present


    position('ELF', 'Type')
    time.sleep(3)
    app.connect("127.0.0.1", 7801, clientId=1)


if __name__ == "__main__":
    main()
