from connection_port import *
from portfolio import *
from openOrder import *

port_list = [port_perso_test(), port_perso_prod(),port_pro_prod(), port_pro_test()]

for port in port_list:
    try:
        main_portfolio(port)
    except:
        pass

for port in port_list:
    try:
        main_openOrder(port)
    except:
        pass
