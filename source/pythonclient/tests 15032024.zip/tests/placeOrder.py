import os
import subprocess
import sys
from datetime import datetime, timedelta
import csv
from send_mail import *
import pandas as pd
from ibapi.client import EClient
from ibapi.contract import Contract
from ibapi.order import Order
from ibapi.wrapper import EWrapper

def install_package(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

try:
    import pandas as pd
    from ibapi.client import EClient
except ImportError:
    print("Pandas n'est pas installé. Installation en cours...")
    install_package("pandas")
    install_package("ibapi")

    import pandas as pd

from ibapi.client import EClient
from ibapi.contract import Contract
from ibapi.order import Order
from ibapi.order_condition import PriceCondition
from ibapi.wrapper import EWrapper

# Exemple d'heure d'annulation : 24 heures à partir de maintenant, en UTC
cancel_time = datetime.utcnow() + timedelta(days=1)
formatted_cancel_time = cancel_time.strftime("%Y%m%d-%H:%M:%S")

# Fonction pour créer un contrat
def create_contract(symbol, secType, exchange, currency):
    contract = Contract()
    contract.symbol = symbol
    contract.secType = secType
    contract.exchange = exchange
    contract.currency = currency

    print("Contract created :" + symbol + " - " + secType + " - " + exchange + " - " + currency)
    return contract


# Fonction pour créer un ordre
def buy_order(quantity):
    order = Order()
    order.orderType = "MKT"
    order.totalQuantity = quantity
    order.action = "BUY"
    order.eTradeOnly = False
    order.firmQuoteOnly = False
    order.transmit = True

    print("Buy Order created : " + order.orderType + " - Qty : " + str(order.totalQuantity) + " - " + order.action)
    return order


# Fonction pour créer un ordre stop limit suiveur
def trailing_stop_order(quantity, trailStopPrice=None, trailAmt=None, trailPercent=None):
    """
    Crée un ordre stop suiveur.

    :param trailStopPrice:
    :param action: 'BUY' ou 'SELL'
    :param quantity: Quantité d'actions à acheter ou vendre
    :param trailAmt: Montant du suivi (trailing amount) en points absolus
    :param trailPercent: Pourcentage du suivi
    :return: Un objet Order configuré comme un ordre stop suiveur
    """
    order = Order()
    order.action = "SELL"
    order.totalQuantity = quantity
    order.orderType = "TRAIL"

    order.eTradeOnly = False
    order.firmQuoteOnly = False
    order.timeInForce = 'GTC'
    order.transmit = True

    if trailStopPrice is not None:
        order.trailStopPrice = trailStopPrice

    if trailAmt is not None:
        order.auxPrice = trailAmt  # Montant du suivi en points absolus
    elif trailPercent is not None:
        order.trailPercent = trailPercent  # Pourcentage du suivi

    print("Trailing stop order created - quantity : "+ str(quantity) +" - trailPercent : " + str(trailPercent) + " - trailAmt : " + str(
        trailAmt) + " - trailStopPrice : " + str(
        trailStopPrice))

    return order


# Classe TradingApp
def create_market_on_close_order(action, quantity, price, isMore, conId):
    order = Order()
    order.action = action
    order.totalQuantity = quantity
    order.orderType = "MOC"
    order.lmtPrice = price
    order.eTradeOnly = False
    order.firmQuoteOnly = False

    price_condition = PriceCondition()
    price_condition.triggerMethod = PriceCondition.TriggerMethodEnum.Last
    price_condition.conId = conId
    price_condition.exchange = "SMART"
    price_condition.price = price
    price_condition.isMore = isMore

    order.conditions.append(price_condition)
    return order


# Function to read a CSV file with various encoding and delimiter attempts
def read_csv_with_encoding_and_delimiter_attempts(file_path):
    encodings = ['utf-8', 'latin1', None]  # Include 'None' for default encoding
    delimiters = [';', ',']

    for encoding in encodings:
        for delimiter in delimiters:
            try:
                df = pd.read_csv(file_path, encoding=encoding, delimiter=delimiter)
                date = df['DATE']
                return df
            except:
                continue

def present(data, action, position_type, currency="USD"):
    present = False
    try:
        if action in data:  # Check if the action is present in the data keys
            response = "SYMBOL : " + action + " - POSITION : " + data[action]['Type'] + " - QUANTITY : " + str(
                data[action]['Quantity'])

            if data[action]['Type'] == position_type and data[action]['Currency'] == currency:
                print("Position présente")
                print(response)
                present = True
            else:
                print("Symbol présent mais position absente")
                print("SYMBOL : " + action + " - POSITION : " + position_type)
                print("----------------------------------------------")
                print("Position actuelle pour " + action)
                print(response)
        else:
            print("Position absente")
            print("SYMBOL : " + action + " - POSITION : " + position_type)
    except KeyError as e:
        print("KeyError:", e)
        print("Position absente - KeyError occurred while accessing data for", action)
    except Exception as e:
        print("An error occurred:", e)
        print("Position absente - Error occurred while processing data for", action)

    return present

class TradingApp(EWrapper, EClient):
    def __init__(self):
        EClient.__init__(self, self)
        self.nextOrderId = 0
        self.order_queue = []  # File d'attente pour les ordres
        self.conId = None
        self.positions = {}  # Dictionnaire pour stocker les positions ouvertes
        self.data = pd.DataFrame(self.positions)
        self.open_orders = []

    def nextValidId(self, orderId: int):
        super().nextValidId(orderId)
        self.nextOrderId = orderId
        self.process_order_queue()

    def process_order_queue(self):
        for contract, order in self.order_queue:
            self.placeOrder(self.nextOrderId, contract, order)
            self.nextOrderId += 1
        self.order_queue.clear()

    def add_order(self, contract, order):
        self.order_queue.append((contract, order))

    def check_if_order_exists(self, orderId: int) -> bool:
        # Vérifie si l'ordre avec l'ID donné existe dans le dictionnaire d'état
        with self.order_status_lock:
            return orderId in self.order_status and \
                self.order_status[orderId] not in ['Cancelled', 'Filled']

    def contractDetails(self, reqId, contractDetails):
        super().contractDetails(reqId, contractDetails)
        self.conId = contractDetails.contract.conId
        print("self.conId : ")
        print(self.conId)

    def place_order(self, contract, order):
        self.placeOrder(self.nextOrderId, contract, order)

    def position(self, account, contract: Contract, pos, avgCost):
        # Callback qui reçoit les informations de position
        if pos > 0:
            position_type = "BUY"  # Position longue
        elif pos < 0:
            position_type = "SELL"  # Position courte
        else:
            position_type = "NEUTRAL"

        self.positions[contract.symbol] = {
            "Type": position_type,
            "Quantity": abs(pos),
            "Average Cost": round(avgCost, 2),
            "Currency": contract.currency,
            "Instrument": contract.secType
        }
        self.data = pd.DataFrame(self.positions)
        self.data = self.data.loc[:, self.data.loc["Quantity"] != 0]
        self.data.to_csv("C:\\TWS API\\source\\pythonclient\\tests\\Data\\positions.csv",index=False)

    def positionEnd(self):
        # Callback indiquant la fin de la transmission des positions
        self.disconnect()  # Déconnexion après avoir reçu toutes les positions

    def retPositions(self):
        return self.positions

    def openOrder(self, orderId, contract: Contract, order: Order, orderState):
        """ Callback to receive open order information """
        # Simplify and select the data you need
        order_info = {
            "index": len(self.open_orders) + 1,
            "orderId": orderId,
            "symbol": contract.symbol,
            "secType": contract.secType,
            "currency": contract.currency,
            "action": order.action,
            "orderType": order.orderType,
            "totalQty": order.totalQuantity,
            "lmtPrice": order.lmtPrice,
            "auxPrice": order.auxPrice,
            "status": orderState.status,
        }
        self.open_orders.append(order_info)

    def openOrderEnd(self):
        """ Indicates the end of the initial open orders' download """
        super().openOrderEnd()
        print("Received all open orders. Saving to CSV file.")
        self.save_orders_to_csv()

    def save_orders_to_csv(self):
        """ Save the collected order information to a CSV file """
        fields = ['index', 'orderId', 'symbol', 'secType', 'currency', 'action', 'orderType', 'totalQty', 'lmtPrice',
                  'auxPrice', 'status']
        existing_order_ids = set()

        csv_file_path = "C:\\TWS API\\source\\pythonclient\\tests\\Data\\open_orders.csv"

        # Collect existing order IDs from the CSV
        if os.path.exists(csv_file_path):
            try:
                existing_orders_data = pd.read_csv(csv_file_path)
                if not existing_orders_data.empty:
                    existing_order_ids = set(existing_orders_data['orderId'])
            except (FileNotFoundError, pd.errors.EmptyDataError):
                pass  # If the file doesn't exist or is empty, ignore the exception

        with open(csv_file_path, 'a', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fields)

            # Only write orders that don't have duplicate orderIds
            for order in self.open_orders:
                if order['orderId'] not in existing_order_ids:
                    writer.writerow(order)
                    existing_order_ids.add(order['orderId'])

        print("Open orders have been saved to open_orders.csv")

    def error(self, reqId, errorCode, errorString, *args):
        """ Handle errors with an additional arguments placeholder """
        print(f"Error: {reqId}, {errorCode}, {errorString}")
        # if args:
        #     print(f"Additional info: {args}")

    def orderId_present(self, action, side, currency="USD"):

        try:
            data = pd.read_csv("C:\\TWS API\\source\\pythonclient\\tests\\Data\\open_orders.csv", index_col=0)
            data = data[data['action'] == side]
            data = data[data['symbol'] == action]
            data = data[data['secType'] == 'STK']
            data = data[data['currency'] == currency]

            if not data.empty:  # Check if DataFrame is not empty
                print("OrderId present")
                return list(set(data['orderId'].values))
            else:
                print("No orderId present")
                return []
        except Exception as e:
            print("Error:", e)
            print("No orderId present")
            pass

    def all_orderId(self):
        csv_file_path = "C:\\TWS API\\source\\pythonclient\\tests\\Data\\open_orders.csv"

        if os.path.exists(csv_file_path) and os.path.getsize(csv_file_path) > 0:
            data = pd.read_csv(csv_file_path, index_col=0)
            print("----ALL ORDERID----")
            orderIds = list(set(data['orderId'].values))
            print(orderIds)
            return orderIds
        else:
            return []

    def sendOpenOrders(self):
        data = pd.read_csv("C:\\TWS API\\source\\pythonclient\\tests\\Data\\open_orders.csv", index_col=0)

        data = data.reset_index(drop=True)

        html_data = '<p>(TWS) Open Orders</p>' + data.to_html()

        send_mail_html("IBKR TWS Open Orders", html_data)


    # def error(self, reqId, errorCode, errorString, advancedOrderRejectJson=None):
    #     print("Error: ", reqId, " ", errorCode, " ", errorString)
    #     if advancedOrderRejectJson:
    #         print("Advanced order rejection info:", advancedOrderRejectJson)
