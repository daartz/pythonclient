def port():
    return 4002

def port_perso_test():
    return 4002

def port_perso_prod():
    return 4001

def port_pro_test():
    return 5002

def port_pro_prod():
    return 5001

def index_pro():
    index = [ 'US9']
    return index

def index_perso():
    index = ['US IPO']
    return index

def index_test():
    index = ['GERMANY', 'FRANCE', 'US9', 'ITALY', 'SPAIN', 'BELGIUM', 'US IPO', "NDL", "SWITZERLAND"]
    return index