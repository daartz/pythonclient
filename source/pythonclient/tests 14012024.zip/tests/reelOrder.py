import os
import threading
from threading import Thread, Lock
from positions import main

import pandas as pd

from marketHours import *
from placeOrder_v2 import *
import time

main()

# Current date in YYYY-MM-DD format
today = datetime.now().date()

# Connection details to IBKR
HOST = '127.0.0.1'
PORT = 7497
PORT = 4002  # Pour IBKR GATEWAY
CLIENT_ID = 100  # Unique for each connection

index = ['GERMANY', 'FRANCE', 'US9', 'ITALY', 'SPAIN', 'BELGIUM', 'US8', 'US7', 'US IPO1', 'US IPO2']

# Initialize the trading application
app = TradingApp()
app.connect(HOST, PORT, CLIENT_ID)

data= pd.read_csv("actual_positions.csv", index_col=0)

print(present(data,'HARP', 'SELL', "USD"))

orders = ['buy', 'sell']

for country in index:
    print(country)

    for order in orders:

        csv_file_path = f'C:\\Users\\daart\\OneDrive\\PROREALTIME\\Signals\\{country} {order} signals {today}.csv'

        if not os.path.exists(csv_file_path):
            print(f"File not found: {csv_file_path}")
            continue

        # Read the CSV file
        df = read_csv_with_encoding_and_delimiter_attempts(csv_file_path)

        if df is None:
            continue

        # Convert the 'DATE' column to datetime and filter for today's date
        df['DATE'] = pd.to_datetime(df['DATE'], errors='coerce')

        # Filter the DataFrame for today's date
        today = datetime.now().date()

        df_today = df[df['DATE'] == str(today)]

        df_today = df[df['ORDER'] != 'HOLD']

        # Process orders
        for index, row in df_today.iterrows():

            date = datetime.strptime(str(row['DATE']), "%Y-%m-%d %H:%M:%S")
            date = date.strftime("%Y-%m-%d")

            if str(date) != str(today):
                continue
            print('-------------------------------------------------------------------')
            print('****   ' + row['STOCK'] + ' - ' + row['NAME'] + ' - ' + row['ORDER'] + ' - ' + str(
                row['BUY']) + ' - ' + str(
                row['DATE']) + '   ****')

            stock = row['STOCK'].split('.')[0]
            secType = "STK"
            exchange = "SMART"

            valq = 0
            if "US9" in country:
                currency = "USD"
                valq = 500
            elif "US" in country and country != "US9":
                currency = "USD"
                nb = 200
            else:
                currency = "EUR"
                valq = 1000

            order = row['ORDER']
            quantity = valq // row['BUY']
            price = row['BUY']

            contract = create_contract(stock, secType, exchange, currency)

            if row['ORDER'] == "BUY":

                trailPercent = 4
                trailAmt = round(price * trailPercent / 100, 2)
                trailStopPrice = row['STOP']
                order = buy_order(quantity)
                # order.transmit = False
                app.add_order(contract, order)

                order = trailing_stop_order(quantity, trailStopPrice=trailStopPrice, trailAmt=trailAmt,
                                            trailPercent=trailPercent)
                # order.transmit =False
                app.add_order(contract, order)

            elif row['ORDER'] == "SELL":

                if present(data,stock, "BUY", currency):

                # vérifier qu'il y a des positions ouvertes pour ce contrat

                # if data[stock].name:
                #     print("Position ouverte pour " + stock)
                # else:
                #     print("Aucune position pour" + stock)
                # annuler le précédent ordre de stop suiveur
                    trailPercent = 1
                    trailAmt = round(price * trailPercent / 100, 3)
                    order = trailing_stop_order(quantity, trailStopPrice=row['SELL'], trailAmt=round(trailAmt, 2),
                                                trailPercent=trailPercent)

                    app.add_order(contract, order)


# Run the app and disconnect after processing all files
try:

    app.run()
except:
    print("Connection failed")
finally:

    app.disconnect()
    app.connect(HOST, 7800, CLIENT_ID)
