import os
from threading import Thread

from marketHours import *
from placeOrder_v2 import *
import time

from tests.positions import Trading_App

app = Trading_App()
PORT = 7497
PORT = 4002
app.connect("127.0.0.1", PORT, clientId=1)

con_thread = Thread(target=lambda: app.run())
con_thread.start()

time.sleep(1)  # Laisser le temps pour la connexion

app.reqPositions()  # Demander les positions ouvertes
pos = app.retPositions()
time.sleep(1)  # Attendre la réception des données de position

con_thread.join()  # Attendre que le thread se termine proprement

pres = app.present('HARP', 'VENTE', "USD")
pres
time.sleep(3)
app.connect("127.0.0.1", 7801, clientId=1)